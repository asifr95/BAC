package com.example.bloodalcohol;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class alcoholActivity extends AppCompatActivity {
    int weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alcohol);
        Intent intent = getIntent();


        // Capture the layout's TextView and set the string as its text

        TextView callCab = findViewById(R.id.textView2);
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        TextView t = findViewById(R.id.textView1);


        Double a = Double.parseDouble(message);
        if (a > 0.08) {
            t.setBackgroundColor(Color.parseColor("#E91E63"));
            t.setText("Your Blood Alcohol Level is: " + message+" \nThis is dangerous level please do not drive");
            callCab.setText("Please click here to call cab to your location:");
            callCab.setVisibility(View.VISIBLE);

            //I wanted to implement an API that will call a cab for users who are too drunk
        }else
            t.setText("Your Blood Alcohol Level is: " + message);
    }
}
