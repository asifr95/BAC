package com.example.bloodalcohol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.bloodalcohol.R.id.textView1;

public class MainActivity extends AppCompatActivity {
    public String gender;
    public double alcoholQuantity, alcoholPercentage, time, weight, ER=0.017, genderRate;
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";

    public void clickFunction(View view) {

        //Get and set user gender
        EditText a = (EditText) findViewById(R.id.gender);
        gender= String.valueOf(a.getText());

        if(gender.equalsIgnoreCase("M")){
            genderRate= 3.75;               // for male
        }else if(gender.equalsIgnoreCase("F")){
            genderRate= 4.7;                //for female
        }else
            genderRate = (3.75+4.7)/2;      //avg used for not declaring gender


        //Get and set user weight
        EditText b = (EditText) findViewById(R.id.weight);
        weight = Double.parseDouble(String.valueOf(b.getText()));

        //get and set alcohol quantity
        EditText c = (EditText)findViewById(R.id.alcoholAmount);
        alcoholQuantity = Double.parseDouble(String.valueOf(c.getText()));

        //Get and set alcohol percentage
        EditText d = (EditText)findViewById(R.id.alcoholConcentrate);
        alcoholPercentage = Double.parseDouble(String.valueOf(d.getText()));

        //use doubles to calculate the concentration of alcohol
        double ounceOfAlcohol = alcoholQuantity*(alcoholPercentage/100);

        EditText e = (EditText)findViewById(R.id.aTime);
        time = Double.parseDouble(String.valueOf(e.getText()));

        double answer = (ounceOfAlcohol*ER*genderRate*time)/weight;

        Toast.makeText(MainActivity.this,"YOUR BAC level is  "+ answer, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, alcoholActivity.class);
        String message = String.valueOf(answer);
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}